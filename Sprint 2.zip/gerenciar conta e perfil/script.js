document.getElementById("save-btn").addEventListener("click", function() {
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
  
    if (name === "" || email === "") {
      alert("Por favor, preencha todos os campos obrigatórios.");
      return;
    }
  

    console.log("Dados enviados:", {
      nome: name,
      email: email,
      senha: password || "Senha não alterada",
    });
  
    alert("Alterações salvas com sucesso!");
  });
  