let suggestions = [];

window.onload = () => {
  renderSuggestions();
};

document.getElementById("suggestion-form").addEventListener("submit", (e) => {
  e.preventDefault();
  const suggestionInput = document.getElementById("suggestionInput");
  const suggestionText = suggestionInput.value.trim();
  
  if (suggestionText) {
    suggestions.push(suggestionText);
    suggestionInput.value = "";
    renderSuggestions();
  }
});

function renderSuggestions() {
  const suggestionList = document.getElementById("suggestion-list");
  suggestionList.innerHTML = ""; 

  if (suggestions.length === 0) {
    suggestionList.innerHTML = "<p>Nenhuma sugestão enviada ainda.</p>";
  } else {
    const ul = document.createElement("ul");
    ul.classList.add("list-group");

    suggestions.forEach((suggestion, index) => {
      const li = document.createElement("li");
      li.classList.add("list-group-item");
      li.textContent = suggestion;
      ul.appendChild(li);
    });

    suggestionList.appendChild(ul);
  }
}
